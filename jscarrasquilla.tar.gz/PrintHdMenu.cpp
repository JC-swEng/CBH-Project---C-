#include <iostream>
#include <cstdlib> 

using namespace std;

void PrintHdMenu()
{
   system("clear");
   cout << endl << "\t\t\t* * * Police Information System Main Menu * * *" << endl << endl;
   cout << "\t\t===================================================================";
   cout << endl << "\t\tOption 1: Display Auxiliary Files" << endl << endl;
   cout << "\t\tOption 2: Search by SSN" << endl << endl;
   cout << "\t\tOption 3: Search by OLN" << endl << endl;
   cout << "\t\tOption 4: Add Record" << endl << endl;
   cout << "\t\tOption 5: Delete Record" << endl << endl;
   cout << "\t\tOption 6: Update Record" << endl << endl;
   cout << "\t\tOption 7: Diplay All Records" << endl << endl;
   cout << "\t\tOption 8: Quit" << endl << endl << endl;
   cout << "\tEnter Option Number:";


}

